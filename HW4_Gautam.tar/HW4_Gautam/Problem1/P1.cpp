/// Scrips to caluclate the total energy of the asteroid with the interaction with the users////



#include<iostream>         /// header libraries///

#include<cmath>            /// Math Library///

using namespace std;

/// begining of the program///

int main(){
  

  
  double m,v,r;    /// floating points variables///
  
  cout << "Enter the mass of asteroid(in kg) : " << endl; /// Interaction with the user///
  cin >> m;
  cout << "The mass of asteroid in kg  is: \n" << m  << endl;


  double k;
   cout << "Enter the velocity of asteroid in Km/s:" << endl;
   cin >> k;
   v = k*1000;
   cout << " The velocity of asteroid in meter per second  is "  << v << endl;
  

  double Au;
    cout << "Enter the distance between the asteroid and sun in Au : " << endl;
    cin >> Au;
    r = Au*(1.5e11);
    cout << " The distance betwen the asteroid and sun is"  << r << endl;
    

  double kinEn = m* pow(v,2) * (0.5);

  cout << "The Kinetic energy of asteroid is " << kinEn << "\n Joules" << endl;

  const double G = 6.67E-11;

  const double M = 1.93E30;
  
  
  double potEn = -G*M*m/r;
    cout << "The potential energy of asteroid is " << potEn << "\n Joules" << endl;


     double totalEn;

    totalEn = kinEn + potEn;

    cout << " The total energy of asteroid is "  << totalEn << " Joules" << endl;

    if (totalEn <0)
      {
	cout << "The orbit of the asteroid is Elliptical and the asteroid is in solar system:" <<  endl;
      }
    else if (totalEn >0){
      cout << "The orbit of the asteroid is hyperbolic and the asteroid is in interstellar"<<  endl;
    }
    else
      {
	cout << " The orbit of the asteroid is Parabolic  and the asteroid isin interstellar:" << endl;
      }

    
    
  return 0;
}

