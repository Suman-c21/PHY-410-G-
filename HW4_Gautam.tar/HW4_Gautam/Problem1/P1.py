#!/usr/bin/env python
# coding: utf-8

# In[1]:


''' Python script to calculate the total energy of the asteroid asking user for mass(kg), velocity(m/s) 
and the distance between them(m).'''

import sys
G = 6.673*(10.**-11.) # Universal gravitational Constant (Nm^2/kg^2).
M = 1.989*10.**30.   # Mass of sun (Kg).

m= raw_input('Enter the mass of asteroid: \n') # Mass of asteroid(kg).

m = float(m)

print'The mass of the asteroid is = %d' %m, 'kg'

v = raw_input('Enter the speed of asteroid: \n') # Speed of asteroid(km/s).

v = float(v)*1000. # Speed of asteroid (m/s)

print'The speed of asteroid is = %d' %v, 'm/s'

r = raw_input('Enter the distance between sun and asteroid: \n') # Distance between sun and asteroid(AU).

r = float(r)*(1.5*10**11.) # Distance of asteroid(m/s).

print'The distance between sun and asteroid is = %1.2e' %r,' m'

k = 0.5*m*v**2 # Kinetic Energy of asteroid.

v = -G*M*m/r # Potential Energy of asteroid.

T = k + v 

print'The total energy is : %3.2e'%T,'J'

if T<0:
    print'The orbit of the asteroid is Elliptical and is in the solar system.'  

elif T>0:
    print'The orbit of the asteroid is hyperbolic and is interstellar.'
    
else:
    print'The orbit of the asteroid  is parabolic and interstellar.'


# In[ ]:




