#!/usr/bin/env python
# coding: utf-8

# In[17]:


''' Python Script to measure the time it takes for a computer to multiply 4*4 one hundred million times.'''
import time
start_time = time.time()

for i in range(100000001):
    a=4*4
end_time = time.time()
total_time = end_time-start_time
print'Execution time in seconds: %1.2f' %total_time, 's'


# In[ ]:




