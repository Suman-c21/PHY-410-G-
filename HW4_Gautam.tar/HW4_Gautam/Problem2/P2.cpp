/* Program to measure time takes for a computer to multiply 4*4 one hundred million times.*/

#include<iostream>
using namespace std;

#include <ctime>

int main (){



  clock_t start;

  double ticks_per_second = CLOCKS_PER_SEC;

  double duration;

  start = clock();
  int i;
  double x;
  

  for (i =1;i <=100000000 ;i++){
    x =4*4;

    
  }
  
  duration = (clock () - start )/ticks_per_second;

  cout << "The execution time is : \n" << duration << "seconds \n\n";
					     
  return 0;

  
}
