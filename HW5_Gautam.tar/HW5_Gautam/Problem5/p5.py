'''Python Script to calculate the initial velocity of the bullet and solving the problem to calcualte the final height after rebounding.'''

import numpy as np                 # Import python Libraries.
vx_1 = 472.0
n = int((1021-vx_1)/0.1)           # Creating step size.

for i in range(n):
    vx = vx_1 + 0.1*i              # Muzzle velocity with step size (m/s).
    d =  100.                      # Distance between the gun and impact in meters(m).
    t  =  d/vx                      # Time taken  to reach the impact in seconds (s).
    g =  9.8                       # Acceleration due to gravity (m/s^2).
    h =  0.5*g*t**2                # Height from ground level in meter (m). 

    y1 = 1.3 - h                    # Height where the bullet impact in meter (m).


    vy = g*t                        # Vertical velocity just before collision (m/s).
    v1 = np.sqrt((vx)**2. + (vy)**2.) # Total velocity (m/s).

    m= 4.2e-3                       # Mass of bullet in (kg).
    kb = 0.5*m*(v1**2.)              # Kinetic energy before wall in Joules (J).

    ka = 0.22*kb                    # kinetic energy after wall in Joules(J).
    V = np.sqrt(2.*ka/m)            # Velocity after  wall collision (m/s).

    T1 = d/V                         # Returning time after collision (s).
    h1 = 0.5*g*T1**2.                # Height from ground level after returning (m).
    Y = (y1-h1)*100.                 # Height  the bullet imapct after returning (cm).
    
    if (50<Y<50.2):
        print('The bullet hits the boy in his knee and velocity of the bullet is: = %1.1f m/s. ' %vx)
        break
    else:
        print('The velocity  %1.1f is too low to hit on the knee.'%vx)
