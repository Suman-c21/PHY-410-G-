//C++ to calculate the whether the bullet hits the knee after reflected from the impact.


#include<iostream>                          // Standard C++ Library.
#include<cmath>                             // math Library.
#include<fstream>                           // Libraray to interact with files.
using namespace std;


// Begining of the program.

int main () { 
  double vx,d,t,h,y1,vy,v1,ka,kb,V,T1,h1,Y;  // Defining variables.
  const double g = 9.8;                   // Acceleration due to gravity(m/s^2).
  double m = 4.2e-3;                      // mass of bullet in kg.



  vx = 472.0;                            // Initial horizontal velocity(m/s).
  Y = 20.0;                              // Choosing random distance(cm).
  
  while(Y < 50.0 or Y > 50.2){    
   d =100.0;                              // Distance between man and target(m).
   t = d/vx;                              // Calcualating time(s.                    
   h = 0.5*g*pow(t,2);                     // Height at which the target bounds(m).
   y1 = 1.3 - h;                            // Final rebounding height(m).
   vy = g*t;                               // Vertical velocity(m/s).
   v1 = sqrt(pow(vx,2) + pow(vy,2));        // Total velocity(m/s).
   m = 4.2e-3;                             // Mass of bullet (kg).
   kb = 0.5*m*pow(v1,2);                    // Kinetic energy before wall(J).
   ka = 0.22*kb;                           // Kinetic energy after wall(J).
   V = sqrt(2*(ka/m));                     // Velocity after wall(m/s).
   T1 = d/V;                                // Returning time(s).
   h1 = 0.5*g*pow(T1,2);                    // Height after returning(m).
   Y = (y1-h1)*100.0;                       // Final height(cm).
   
if (Y>=50 and Y<=50.2){
  cout << "Hence,the bullet hits the boy in his knee and the velocity is :\t" << vx << "m/s" << endl;
   }
 
else {
  
  cout << "The bullet velocity " << vx << " is too low to hit on the knee." <<  endl;
  vx += 0.1;
 }
  }   

}
