// General header file for C++ programs 
// in "Numerical Methods for Physics" 

#include <iostream>
#include <fstream>
#include <assert.h>  
#include <math.h>
#include "Matrix.h"
using namespace std;
