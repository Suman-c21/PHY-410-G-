#
# pl_int.py: script to plot data from a file with two columns
#
# to run: execfile('pl_int.py')
#
# Input: data files: x.txt, y.txt, interp-xi.txt, interp-yi.txt
#

#Load libraries
from matplotlib.pyplot import *
from numpy import loadtxt
from pylab import *


#to clear the plot
#clf() 

#define a font type
font = {'fontname'   : 'Arial',
        'color'      : 'black',
        'fontweight' : 'bold',
        'fontsize'   : 18}

#load the data
data = loadtxt("x.txt",dtype="float")
xp = data[:]

data = loadtxt("y.txt",dtype="float")
yp = data[:]

data = loadtxt("interp-xi.txt",dtype="float")
x = data[:]

data = loadtxt("interp-yi.txt",dtype="float")
y = data[:]




#plot the line and the dots
line1 = plot(x,y,'b--',linewidth = 5.0, linestyle = '-',label = "Interpolation")
line2 = plot(xp,yp,'s',markersize = 10, marker = '^',color='r', label = "Red triangle")

#legend
legend(numpoints=1,loc=2)


# x and y limits
xmin = min(xp)-0.1
xmax = max(xp)+1.0
ymin = min(yp)-0.1
ymax = max(yp)+1.0

xlim(xmin,xmax)
ylim(ymin,ymax)

#title and labels
title('Interpolation for Zeroth-order Bessel function',font,fontsize= 18)
xlabel(r'x',font)
ylabel(r'$J_{0}(x)$',font)
#text(4, 6, r' Just for Fun: $\sum_{i=0}^\infty\, x_i$', fontsize=20)


#show figure and save in eps format
show()
#savefig("myplot.eps")
