// Program to interpolate data using lagrange polynomial of order 3.

#include<iostream>

using namespace std;
int main()
{
  
  double x,x1,y1,x2,y2,x3,y3,x4,y4;


  cout << "Enter the value of x1 = \t";
  cin >> x1;
  cout << "Enter the value of y1 = \t";
  cin >> y1;
  cout << "Enter the value of x2 = \t";
  cin >> x2;
  cout << "Enter the value of y2 = \t";
  cin >> y2;
  cout << "Enter the value of x3 = \t";
  cin >> x3;
  cout << "Enter the value of y3 = \t";
  cin >> y3;
  cout << "Enter the value of x4 = \t";
  cin >> x4;
  cout << "Enter the value of y4 = \t";
  cin >> y4;
  cout << "Enter the value of x between x1 and x4 = \t";
  cin >> x;
  
 double yi = ((x - x2)*(x -x3)*(x-x4)/((x1-x2)*(x1-x3)*(x1 - x4)))*y1
   + ((x -x1)*(x-x3)*(x-x4)/((x2 - x1)*(x2 - x3)*(x2 - x4)))*y2
   + ((x - x1)*(x - x2)*(x -x4)/((x3 - x1)*(x3 - x2)*(x3 -x4)))*y3
   + ((x - x1)*(x -x2)*(x- x3)/((x4 - x1)*(x4 -x2)*(x4 -x3)))*y4;

 if (x1 <= x and x <= x4){
  cout << "The value of yi is: = "  << yi <<  "\n";
 }
  
  else {
    cout << "This is error!. \n" << endl;
  } 
  
}


