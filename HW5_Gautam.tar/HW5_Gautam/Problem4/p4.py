
''' Program to interpolate data using Lagrange polynomial to fit quadratic to three data points.'''

import numpy as np                          # Python Library.



x1 = float(input("Enter the value of x1 = \t"))
y1 = float(input("Enter the value of y1 = \t"))
x2 = float(input("Enter the value of x2 = \t"))
y2 = float(input("Enter the vlaue of y2 = \t"))
x3 = float(input("Enter the value of x3 = \t"))
y3 = float(input("Enter the value of y3 = \t"))
x4 = float(input("Enter the value of x4 = \t"))
y4 = float(input("Enter the value of y4 = \t"))
x = float(input("Enter the value  between x1 and x4 = \t"))

yi =  ((x-x2)*(x-x3)*(x-x4)/((x1-x2)*(x1-x3)*(x1-x4)))*y1 +((x-x1)*(x-x3)*(x-x4)/((x2-x1)*(x2-x3)*(x2-x4)))*y2 + ((x-x1)*(x-x2)*(x-x4)/((x3-x1)*(x3-x2)*(x3-x4)))*y3 + ((x-x1)*(x-x2)*(x-x3)/((x4-x1)*(x4-x2)*(x4-x3)))* y4

if (x1 < x and x < x4):
    print('The value of yi is  %1.1f' %yi)
else:
    print("This is Error !")




